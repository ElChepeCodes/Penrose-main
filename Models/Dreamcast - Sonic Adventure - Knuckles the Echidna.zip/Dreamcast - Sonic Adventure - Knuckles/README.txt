Title: Knuckles
Game: Sonic Adventure (1998)
Platform: Sega Dreamcast
Ripped By: Spectro

FAQ:

Q:Why he has 2 models?
R: the one called "knuckles" is the normal one but the "knux" one is used for the glide animation,etc.

Q:How did you ripped this
R: https://github.com/kellsnc/sadx-modding-guide/wiki/Finding-models#file-structure-in-the-dreamcast-version

Q:Do i have to give you credits for using this?
R:if you are going to use them for SFM,GMOD,A fangame,animations no only credit me if you are going to reupload this.

